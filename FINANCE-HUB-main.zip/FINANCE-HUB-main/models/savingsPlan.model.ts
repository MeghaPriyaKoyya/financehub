export interface SavingsPlan {
    savingsPlanId?:number;
    name: string;
    goalAmount: number;
    timeFrame: number;
    riskLevel: string;
    description: string;
    status: string;

}
