import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userviewform',
  templateUrl: './userviewform.component.html',
  styleUrls: ['./userviewform.component.css']
})
export class UserviewformComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
