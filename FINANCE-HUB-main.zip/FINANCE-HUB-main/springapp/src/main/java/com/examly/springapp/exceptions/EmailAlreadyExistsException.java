
package com.examly.springapp.exceptions;

public class EmailAlreadyExistsException extends RuntimeException {
    public  EmailAlreadyExistsException(String message){
        super(message);
    }
}
